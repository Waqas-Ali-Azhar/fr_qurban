<?php

return  array(
	'facebook' => array(
		'label' => __( 'Facebook', 'yith-woocommerce-social-login' ),
		'color' => '#3b5998'
	),
	'twitter'  => array(
		'label' => __( 'Twitter', 'yith-woocommerce-social-login' ),
		'color' => '#00aced'
	),
	'google'   => array(
		'label' => __( 'Google', 'yith-woocommerce-social-login' ),
		'color' => '#dd4b39'
	)
);